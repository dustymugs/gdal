// 
// This code is property of Celartem, Inc dba Extensis.
// Copyright (c) 1995-2023. All rights reserved.
// Use permitted only under license from Extensis.
// 
/* PUBLIC */

#ifndef LTI_STATICZOOMFILTER_H
#define LTI_STATICZOOMFILTER_H

// lt_lib_mrsid_imageFilter
#include "lti_multiresFilter.h"


LT_BEGIN_LIZARDTECH_NAMESPACE

/**
 * magnifies the image by a fixed amount
 *
 * This class magnifies the image by a fixed amount.  In effect this simply changes the
 * width and height of the image statically, i.e. for the life of the
 * pipeline.  The resampling is performed internally by the LTIMultiresFilter
 * class.
 */

typedef LTIMultiResFilter LTIStaticZoomFilter;

LT_END_LIZARDTECH_NAMESPACE

#endif // LTI_STATICZOOMFILTER_H
