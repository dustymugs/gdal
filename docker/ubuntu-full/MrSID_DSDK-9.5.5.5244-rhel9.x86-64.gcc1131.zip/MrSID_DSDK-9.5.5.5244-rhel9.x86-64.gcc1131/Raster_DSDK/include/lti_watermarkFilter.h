// 
// This code is property of Celartem, Inc dba Extensis.
// Copyright (c) 1995-2023. All rights reserved.
// Use permitted only under license from Extensis.
// 
/* PUBLIC */

#ifndef LTI_WATERMARKFILTER_H
#define LTI_WATERMARKFILTER_H

// lt_lib_mrsid_core
#include "lti_imageFilter.h"


LT_BEGIN_LIZARDTECH_NAMESPACE

class LTIEmbeddedImage;

/**
 * insert a watermark image onto an image
 *
 * Inserts a watermark image onto the current image stage.
 */
class LTIWatermarkFilter : public LTIImageFilter
{
   LTI_REFERENCE_COUNTED_BOILERPLATE(LTIWatermarkFilter);
public:
   /**
    * initializer
    *
    * Creates an image stage with the \a watermarkImage overlaid over the \a
    * srcImage at the position specified.
    *
    * The \a edgePadding argument is used to specify the distance (in pixels)
    * between the watermark and the edge of the base image specified by the \a
    * position argument.  (This argument is ignored if LTI_POSITION_CENTER is
    * used.)
    *
    * @param  srcImage     the base image
    * @param  watermarkImage  the watermark to be overlaid
    * @param  position        where to insert the watermark
    * @param  edgePadding     distance (in pixels) between the watermark and
    *                         the base image
    */
   LT_STATUS initialize(LTIImageStage* srcImage,
                        LTIImageStage* watermarkImage,
                        LTIPosition position,
                        lt_uint32 edgePadding);

   LT_STATUS initialize(LTIImageStage* srcImage,
                        LTIImageStage* watermarkImage,
                        float transparency,
                        LTIPosition position,
                        lt_uint32 edgePadding);

   // LTIImageStage
   virtual lt_uint32 getModifications(const LTIScene &scene) const;

protected:
   LT_STATUS decodeBegin(const LTIPixel &pixelProps,
                         const LTIScene &fullScene);
   LT_STATUS decodeStrip(LTISceneBuffer &stripBuffer,
                         const LTIScene &stripScene);
   LT_STATUS decodeEnd(void);

private:
   LTIEmbeddedImage *m_watermark;
};


LT_END_LIZARDTECH_NAMESPACE

#endif // LTI_WATERMARKFILTER_H
