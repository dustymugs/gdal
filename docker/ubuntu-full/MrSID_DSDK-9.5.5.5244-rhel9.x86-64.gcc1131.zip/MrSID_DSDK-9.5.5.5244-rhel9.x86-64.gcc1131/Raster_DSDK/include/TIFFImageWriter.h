// 
// This code is property of Celartem, Inc dba Extensis.
// Copyright (c) 1995-2023. All rights reserved.
// Use permitted only under license from Extensis.
// 
/* PUBLIC */

#ifndef TIFFIMAGEWRITER_H
#define TIFFIMAGEWRITER_H

// lt_lib_mrsid_core
#include "lti_geoFileImageWriter.h"

struct tiff;


LT_BEGIN_LIZARDTECH_NAMESPACE

class LTReusableBuffer;

/**
 * writes an image stage to a TIFF file
 *
 * This class writes an image stage to a TIFF file.
 */
class TIFFImageWriter : public LTIGeoFileImageWriter
{
   LT_DISALLOW_COPY_CONSTRUCTOR(TIFFImageWriter);
public:
   /**
    * constructor
    *
    * Creates a writer for TIFF images.
    *
    * @param  writeGeoTIFF  if true the writer will include GeoTIFF tags
    */
   TIFFImageWriter(bool writeGeoTIFF = false);

   virtual ~TIFFImageWriter();
   LT_STATUS initialize(LTIImageStage *image);

   /**
    * Write a BigTIFF if the the scene may produce a file greater than 4GB.
    *
    * @param allowBigTIFF set to true to write a BigTIFF if needed
    */
   void setAllowWritingBigTIFF(bool allowBigTIFF);
   /**
    * Write a BigTIFF.
    *
    * @param forceBigTIFF set to true to write a BigTIFF
    */
   void setForceWritingBigTIFF(bool forceBigTIFF);

   LT_STATUS writeBegin(const LTIScene& scene);
   LT_STATUS writeStrip(LTISceneBuffer& stripBuffer, const LTIScene& stripScene);
   LT_STATUS writeEnd();


   void setEndian(LTIEndian value);
   void setCompression(lt_int32 compression) { m_compression = compression; }
   void setJpegQuality(lt_int32 quality) { m_jpegquality= quality; }

private:
   LT_STATUS copyMetadataBlob(const char *type, lt_uint32 tag);
   static LT_STATUS getLibtiffError(void);

   struct tiff *m_tiff;
   LTIEndian m_endian;

   bool m_writeGeoTIFF;
   bool m_allowBigTIFF;
   bool m_forceBigTIFF;

   long m_currentRow;
   lt_int32 m_compression;
   lt_int32 m_jpegquality;
   LTReusableBuffer* m_stripBuffer;
};


LT_END_LIZARDTECH_NAMESPACE

#endif // TIFFIMAGEWRITER_H
