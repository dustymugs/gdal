// 
// This code is property of Celartem, Inc dba Extensis.
// Copyright (c) 1995-2023. All rights reserved.
// Use permitted only under license from Extensis.
// 
/* PUBLIC */

#ifndef GEOTIFFIMAGEWRITER_H
#define GEOTIFFIMAGEWRITER_H

// lt_lib_mrsid_imageWriters
#include "TIFFImageWriter.h"

LT_BEGIN_LIZARDTECH_NAMESPACE

/**
 * writes an image stage to a GeoTIFF file
 *
 * This class writes an image stage to a GeoTIFF file.
 */
class GeoTIFFImageWriter : public TIFFImageWriter
{
   LT_DISALLOW_COPY_CONSTRUCTOR(GeoTIFFImageWriter);
public:
   GeoTIFFImageWriter(void);
};

LT_END_LIZARDTECH_NAMESPACE

#endif // GEOTIFFIMAGEWRITER_H
