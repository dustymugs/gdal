// 
// This code is property of Celartem, Inc dba Extensis.
// Copyright (c) 1995-2023. All rights reserved.
// Use permitted only under license from Extensis.
// 
/* PUBLIC */

#ifndef LTI_COLORTRANSFORMER_H
#define LTI_COLORTRANSFORMER_H

// lt_lib_mrsid_core
#include "lti_imageFilter.h"
#include "lti_imageStageOverrides.h"


LT_BEGIN_LIZARDTECH_NAMESPACE

/**
 * change the colorspace of the image
 *
 * This class changes the colorspace of the image.
 *
 * The supported color transforms are:
 * \li from RGB to CMYK, GRAYSCALE, or YIQ
 * \li from GRAYSCALE to RGB
 * \li from CMYK to RGB, RGBK, or YIQK
 * \li from YIQ to RGB
 * \li from YIQK to CMYK
 */
#ifdef SWIG
class LTIColorTransformer : public LTIImageFilter
#else
class LTIColorTransformer : public LTIOverrideMetadata
                                   <LTIOverridePixelProps<LTIImageFilter> >
#endif
{
   LTI_REFERENCE_COUNTED_BOILERPLATE(LTIColorTransformer);
public:
   /**
    * initializer
    *
    * Creates an image stage with the given colorspace.  The sample values
    * will undergo the requisite color transform function to map from the
    * input colorspace to the output colorspace.
    *
    * @param  srcImage    the base image
    * @param  dstPixel    the desired output pixel properties
    */
   LT_STATUS initialize(LTIImageStage* srcImage,
                        const LTIPixel &dstPixel);

   static bool isSupportedTransform(const LTIPixel &srcPixel,
                                    const LTIPixel &dstPixel);

   // LTIImageStage
   lt_uint32 getModifications(const LTIScene &scene) const;
   LT_STATUS getMetadataBlob(const char *type, LTIOStreamInf *&stream) const;
   bool hasMetadataBlob(const char *type) const;

   static LT_STATUS push(LTIImageStage *&pipeline, const LTIPixel &pixelProps);
   static LT_STATUS push(LTIImageStage *&pipeline, LTIColorSpace colorSpace);
   
   static LT_STATUS transformPixel(LTIPixel &newPixel, const LTIPixel &oldPixel);

   static LT_STATUS transformBuffer(LTISceneBuffer &dstData, LTISceneBuffer &srcData);

protected:
   LT_STATUS decodeBegin(const LTIPixel &pixelProps,
                         const LTIScene &fullScene);
   LT_STATUS decodeStrip(LTISceneBuffer &stripBuffer,
                         const LTIScene &stripScene);
   LT_STATUS decodeEnd(void);

private:
   LTIPixel *m_tmpDstPixel;
   LTIPixel *m_tmpSrcPixel;
   bool m_isIdentity;
};


LT_END_LIZARDTECH_NAMESPACE


#endif // LTI_COLORTRANSFORMER_H
