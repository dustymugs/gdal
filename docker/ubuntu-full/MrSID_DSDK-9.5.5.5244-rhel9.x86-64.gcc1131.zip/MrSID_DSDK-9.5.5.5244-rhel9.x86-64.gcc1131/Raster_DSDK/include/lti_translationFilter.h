// 
// This code is property of Celartem, Inc dba Extensis.
// Copyright (c) 1995-2023. All rights reserved.
// Use permitted only under license from Extensis.
// 
/* PUBLIC */

#ifndef LTI_TRANSLATIONFILTER_H
#define LTI_TRANSLATIONFILTER_H

// lt_lib_mrsid_core
#include "lti_imageFilter.h"
#include "lti_imageStageOverrides.h"

LT_BEGIN_LIZARDTECH_NAMESPACE


/**
 * translates (moves) the geo coordinates of the image
 *
 * This class translates (moves) the geo coordinates of the image.
 */
#ifdef SWIG
class LTITranslationFilter : public LTIImageFilter
#else
class LTITranslationFilter : public LTIOverrideGeoCoord
                                    <LTIImageFilter>
#endif
{
   LTI_REFERENCE_COUNTED_BOILERPLATE(LTITranslationFilter);
public:
   /**
    * initialize
    *
    * This class shifts the geographic coordinates of the image by the given
    * amount.
    *
    * @param  srcImage   the base image
    * @param  xOffset       amount to shift in the X direction
    * @param  yOffset       amount to shift in the Y direction
    */
   LT_STATUS initialize(LTIImageStage* srcImage,
                        double xOffset,
                        double yOffset);

   LT_STATUS initialize(LTIImageStage* srcImage,
                        const LTIGeoCoord &geoCoord);

   // LTIImageStage
   virtual lt_uint32 getModifications(const LTIScene &scene) const;
};


LT_END_LIZARDTECH_NAMESPACE

#endif // LTI_TRANSLATIONFILTER_H
