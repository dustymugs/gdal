// 
// This code is property of Celartem, Inc dba Extensis.
// Copyright (c) 1995-2023. All rights reserved.
// Use permitted only under license from Extensis.
// 
/* PUBLIC */

#ifndef LT_IO_MEM_STREAM_H
#define LT_IO_MEM_STREAM_H

#include "lt_ioStreamInf.h"
#include <stddef.h>

LT_BEGIN_LIZARDTECH_NAMESPACE


/**
 * Stream which wraps an array of bytes in memory.
 *
 * The buffer is of a fixed size and does not grow or shrink.
 */
class LTIOMemStream : public LTIOStreamInf
{
public:
   LTIOMemStream();
   virtual ~LTIOMemStream();

   /** 
    * @name Initialization functions
    */
   /*@{*/
   /**
    * Initializes the stream
    *
    * @param   data  pointer to start of buffer
    * @param   size  size of buffer in bytes
    */
   virtual LT_STATUS initialize( void* data, size_t size );

   /**
    * Initializes the stream
    *
    * This version internally allocates a buffer of the specified size.
    * 
    * @param   size  size of buffer in bytes
    */
   virtual LT_STATUS initialize( size_t size );
   /*@}*/

   virtual bool isEOF();
   virtual bool isOpen();
   virtual LT_STATUS open();
   virtual LT_STATUS close();
   virtual lt_uint32 read( lt_uint8 *pDest, lt_uint32 numBytes );
   virtual lt_uint32 write( const lt_uint8 *pSrc, lt_uint32 numBytes );
   virtual LT_STATUS seek( lt_int64 offset, LTIOSeekDir origin );
   virtual lt_int64 tell();
   virtual LTIOStreamInf* duplicate();
   virtual LT_STATUS getLastError() const;
   virtual const char* getID() const;

protected:

   /**   pointer to buffer */
   lt_uint8*   m_data;

   /**   size of buffer */
   size_t   m_size;

   /**   current position  */
   size_t   m_cur;

   /**   data ownership */
   bool        m_ownsData;

   /**   openness */
   bool        m_isOpen;

   bool m_isEOF;
};


LT_END_LIZARDTECH_NAMESPACE


#endif   // LT_IO_MEM_STREAM_H
