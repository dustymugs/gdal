// 
// This code is property of Celartem, Inc dba Extensis.
// Copyright (c) 1995-2023. All rights reserved.
// Use permitted only under license from Extensis.
// 
/* PUBLIC */

#ifndef LTI_VERSION_H
#define LTI_VERSION_H

#define LTI_SDK_VERSION 0x0955
#define LTI_SDK_MAJOR  9
#define LTI_SDK_MINOR  5
#define LTI_SDK_REV    5

#endif // LTI_VERSION_H

