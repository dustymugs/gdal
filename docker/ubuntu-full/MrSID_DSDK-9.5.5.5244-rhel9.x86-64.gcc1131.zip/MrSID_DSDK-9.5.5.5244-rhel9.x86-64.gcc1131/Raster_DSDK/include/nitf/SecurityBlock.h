// 
// This code is property of Celartem, Inc dba Extensis.
// Copyright (c) 1995-2023. All rights reserved.
// Use permitted only under license from Extensis.
// 
/* PUBLIC */

#ifndef SecurityBlock_H
#define SecurityBlock_H

// lt_lib_base
#include "lt_base.h"

// local
#include "nitf_types.h"

LT_BEGIN_LIZARDTECH_NAMESPACE
class LTIMetadataDatabase;

namespace Nitf {

class FieldReader;
class MetadataHelper;
class SecurityMetadata;


/**
 * container for security-related metadata
 *
 * This class is a container for all the security-related metadata
 * in an NITF file, including the file header security fields and the
 * security fields of the various segments.
 *
 * The actual security properties can be obtained via the
 * SecurityMetadata object returned from the getMetadata()
 * function in this class.
 */  
class SecurityBlock
{
public:
   SecurityBlock(FieldReader&, Version, const char* tagPrefix);
   ~SecurityBlock();

   LT_STATUS addMetadata(LTIMetadataDatabase&);

   const SecurityMetadata* getMetadata() const;

private:
   void read20();
   void read21();

   const Version m_version;
   FieldReader& m_reader;

   MetadataHelper* m_mdHelper;

   SecurityMetadata* m_metadata;

   // nope
   SecurityBlock(SecurityBlock&);
   SecurityBlock& operator=(const SecurityBlock&);
};


}
LT_END_LIZARDTECH_NAMESPACE

#endif // SecurityBlock_H
