// 
// This code is property of Celartem, Inc dba Extensis.
// Copyright (c) 1995-2023. All rights reserved.
// Use permitted only under license from Extensis.
// 
/* PUBLIC */

#ifndef LTI_CROPFILTER_H
#define LTI_CROPFILTER_H

// lt_lib_mrsid_imageFilters
#include "lti_embeddedImage.h"


LT_BEGIN_LIZARDTECH_NAMESPACE

/**
 * crops the image stage to a smaller width and height
 *
 * This class crops the image stage to a smaller width and height.
 */
class LTICropFilter : public LTIEmbeddedImage
{
   LTI_REFERENCE_COUNTED_BOILERPLATE(LTICropFilter);
public:
   /**
    * initializer
    *
    * Creates an image stage which corresponds to a cropped subsection of the
    * input image, according to the given offset, width, and height.
    *
    * @param  srcImage    the base image
    * @param  xOffset        x-position of the origin of the new image
    *                        (specified relative to the input image)
    * @param  yOffset        y-position of the origin of the new image
    *                        (specified relative to the input image)
    * @param  newWidth       width of the new image
    * @param  newHeight      height of the new image
    */
   LT_STATUS initialize(LTIImageStage* srcImage,
                        lt_int32 xOffset,
                        lt_int32 yOffset,
                        lt_int32 newWidth,
                        lt_int32 newHeight);
};


LT_END_LIZARDTECH_NAMESPACE

#endif // LTI_CROPFILTER_H
