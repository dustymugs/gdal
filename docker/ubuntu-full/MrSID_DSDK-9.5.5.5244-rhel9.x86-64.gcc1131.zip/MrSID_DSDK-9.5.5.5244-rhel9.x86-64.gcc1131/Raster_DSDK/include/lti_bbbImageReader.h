// 
// This code is property of Celartem, Inc dba Extensis.
// Copyright (c) 1995-2023. All rights reserved.
// Use permitted only under license from Extensis.
// 
/* PUBLIC */

#ifndef LTI_BBB_IMAGE_READER_H
#define LTI_BBB_IMAGE_READER_H

// lt_lib_mrsid_core
#include "lti_rawImageReader.h"

// system
#include <stdio.h>  // for FILE*

LT_BEGIN_LIZARDTECH_NAMESPACE

class LTIBBBHeaderReader;

/**
 * read an image from a BBB file
 *
 * This class provides support for reading BBB files, i.e. a raw file with a
 * BIL/BIP/BSQ-style header.
 *
 */
class LTIBBBImageReader : public LTIRawImageReader
{
   LTI_REFERENCE_COUNTED_BOILERPLATE(LTIBBBImageReader);
public:
   /**
    * intializer
    *
    * This function creates an image from a BBB file.
    *
    * @param fileSpec      the image file to read from
    * @param useWorldFile  use world file information if available
    */
   LT_STATUS initialize(const LTFileSpec& fileSpec, bool useWorldFile = true);

   /**
    * intializer
    *
    * This function creates an image from a BBB file.
    *
    * @param file          the image file to read from
    * @param useWorldFile  use world file information if available
    */
   LT_STATUS initialize(const char* file, bool useWorldFile = true);
};

#ifndef DOXYGEN_EXCLUDE

class LTIBBBHeaderReader
{
   LT_DISALLOW_COPY_CONSTRUCTOR(LTIBBBHeaderReader);

public:
   LTIBBBHeaderReader(const LTFileSpec&);
   ~LTIBBBHeaderReader();
   LT_STATUS read();

public:
   int            m_width;
   int            m_height;
   LTIDataType    m_dataType;
   LTIColorSpace  m_colorSpace;
   int            m_numBands;
   LTILayout      m_layout;
   char*          m_byteOrder;
   int            m_numBits;
   LTIEndian      m_endian;

   double         m_window;
   double         m_level;
   double         m_drMin;
   double         m_drMax;
   bool           m_hasWindow;
   bool           m_hasLevel;
   bool           m_hasDRMin;
   bool           m_hasDRMax;

   int            m_bandgapbytes;
   int            m_bandrowbytes;
   int            m_totalrowbytes;
   int            m_skipbytes;

   bool           m_hasUlxmap;
   bool           m_hasUlymap;
   bool           m_hasXllcorner;
   bool           m_hasYllcorner;
   bool           m_hasXllcenter;
   bool           m_hasYllcenter;
   bool           m_hasXdim;
   bool           m_hasYdim;
   bool           m_hasCellsize;
   double         m_ulxmap;
   double         m_ulymap;
   double         m_xllcorner;
   double         m_yllcorner;
   double         m_xllcenter;
   double         m_yllcenter;
   double         m_xdim;
   double         m_ydim;
   double         m_cellsize;

   // Imagine header data
   bool        m_bFromImagine; //indicates whether to display Imagine Metadata
   char*       m_projname;
   char*       m_sphereName;
   char*       m_units;
   int         m_proZone;
   double*     m_projParams;
   double      m_sphereMajor;
   double      m_sphereMinor;
   double      m_sphereEccentricitySquared;
   double      m_sphereRadius;

   char*       m_wkt;
   double*     m_nodata;
   int         m_nodataSize;

private:
   LT_STATUS init();
   LT_STATUS finish();
   LT_STATUS readLines();
   LT_STATUS readLine(int& offset_last, bool& done);
   LT_STATUS nextLine();
   LT_STATUS readInt(int&);
   LT_STATUS readDouble(double&);
   LT_STATUS readString(char*);

   const LTFileSpec& m_fileSpec;
   FILE* m_fp;
};
#endif

LT_END_LIZARDTECH_NAMESPACE

#endif // LTI_BBB_IMAGE_READER_H
