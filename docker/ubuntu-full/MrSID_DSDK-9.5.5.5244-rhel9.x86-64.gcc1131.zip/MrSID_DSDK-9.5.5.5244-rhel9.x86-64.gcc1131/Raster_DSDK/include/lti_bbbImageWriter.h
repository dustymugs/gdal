// 
// This code is property of Celartem, Inc dba Extensis.
// Copyright (c) 1995-2023. All rights reserved.
// Use permitted only under license from Extensis.
// 
/* PUBLIC */

#ifndef LTI_BBBIMAGEWRITER_H
#define LTI_BBBIMAGEWRITER_H

// lt_lib_mrsid_core
#include "lti_rawImageWriter.h"

LT_BEGIN_LIZARDTECH_NAMESPACE

/**
 * writes an image stage to a BBB file
 *
 * This class provides support for writing BBB files, i.e. a raw file with a BBB-style
 * header.
 */
class LTIBBBImageWriter : public LTIRawImageWriter
{
   LT_DISALLOW_COPY_CONSTRUCTOR(LTIBBBImageWriter);
public:
   LTIBBBImageWriter(void);
   virtual ~LTIBBBImageWriter(void);

   LT_STATUS writeBegin(const LTIScene& scene);
   LT_STATUS deleteOutput(void);

   static LT_STATUS writeHeader(const LTFileSpec& fileSpec,
                                const LTIImage& image,
                                const LTIScene* userScene,
                                LTIEndian byteOrder,
                                LTILayout layout);

   
   
private:
   LT_STATUS checkImpedance() const;

   LT_STATUS writeHeader(const LTIScene&);
};


LT_END_LIZARDTECH_NAMESPACE


#endif // LTI_BBBIMAGEWRITER_H
